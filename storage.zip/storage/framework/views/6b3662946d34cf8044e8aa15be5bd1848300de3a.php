<?php $__env->startSection("content"); ?>

    <div class="col-sm-9">
        <div class="blog-post-area">
            <h2 class="title text-center">How To Buy</h2>
            <div class="single-blog-post">

                <h3>TRANSFER KE REK</h3>
                <ul>
                    <li>1. BCA. NO REK : 5680349179. A/N AGUS NURKHOLIS</li>
                    <li>2. BANK MANDIRI. NO REK : 167 000 113 1100. A/N AGUS NURKHOLIS</li>

                </ul>

                <p>

                </p>

            </div>
        </div><!--/blog-post-area-->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("frontend.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>