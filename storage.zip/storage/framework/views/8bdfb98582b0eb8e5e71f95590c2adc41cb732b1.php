<?php $__env->startSection("content"); ?>

    <div class="col-sm-9 padding-right">
        <div class="features_items"><!--features_items-->
            <h2 class="title text-center">Search (<b><?php echo e(str_replace("-"," ",$keyword)); ?></b>)</h2>
            <?php foreach($products as $item): ?>
                <div class="col-sm-4">
                    <div class="product-image-wrapper">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                <img src="<?php echo e(asset('uploaded/'.$item->pict_1)); ?>" alt="<?php echo e($item->p_name); ?>" width="268px" height="249px" />
                                <h2>Rp <?php echo e(number_format($item->price)); ?></h2>
                                <p><?php echo e($item->p_name); ?></p>
                                <a href="<?php echo e(url('product/show/'.$item->id.'/'.str_replace(' ','-',strtolower($item->p_name)))); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View detail</a>
                            </div>
                            <div class="product-overlay">
                                <div class="overlay-content">
                                    <h2>Rp <?php echo e(number_format($item->price)); ?></h2>
                                    <p><?php echo e($item->p_name); ?></p>
                                    <a href="<?php echo e(url('product/show/'.$item->id.'/'.str_replace(' ','-',strtolower($item->p_name)))); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View detail</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            <?php endforeach; ?>


            <?php echo $products->links(); ?>


        </div><!--features_items-->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("frontend.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>