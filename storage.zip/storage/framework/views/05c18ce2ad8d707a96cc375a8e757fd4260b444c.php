<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo e($title); ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('assets/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo e(asset('assets/bower_components/metisMenu/dist/metisMenu.min.css')); ?>" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="<?php echo e(asset('assets/dist/css/timeline.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent("custom_css"); ?>

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('assets/dist/css/sb-admin-2.css')); ?>" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="<?php echo e(asset('assets/bower_components/morrisjs/morris.css')); ?>" rel="stylesheet">



    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('assets/bower_components/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Express Korean Motor CMS v1</a>
        </div>
        <!-- /.navbar-header -->

        <ul class="nav navbar-top-links navbar-right">
            <!-- /.dropdown -->
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                </a>
                <ul class="dropdown-menu dropdown-user">
                    <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile (<?php echo e(Auth::user()->u_name); ?>)</a>
                    </li>
                    <li class="divider"></li>
                    <li><a href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                </ul>
                <!-- /.dropdown-user -->
            </li>
            <!-- /.dropdown -->
        </ul>
        <!-- /.navbar-top-links -->

        <?php
            $path = Route::getCurrentRoute()->getPath();
            $explode = explode('/',$path);

        ?>
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">

                    <li>
                        <a href="<?php echo e(route('home')); ?>" <?php if($explode[1] == "home"): ?> class="active" <?php endif; ?>><i class="fa fa-dashboard fa-fw"></i> Home</a>
                    </li>
                    <li <?php if(isset($explode[1])): ?> <?php if($explode[1] == "master"): ?> class="active" <?php endif; ?> <?php endif; ?>>
                        <a href="#"><i class="fa fa-edit fa-fw"></i> Master Data<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse <?php if(isset($explode[1])): ?> <?php if($explode[1] == "master"): ?> in <?php endif; ?> <?php endif; ?> ">
                            <li>
                                <a href="<?php echo e(route('user.list')); ?>" <?php if(isset($explode[2])): ?> <?php if($explode[2] == "user"): ?> class="active" <?php endif; ?> <?php endif; ?>>Users</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('category.list')); ?>" <?php if(isset($explode[2])): ?> <?php if($explode[2] == "category"): ?> class="active" <?php endif; ?> <?php endif; ?>>Categories</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('product.list')); ?>" <?php if(isset($explode[2])): ?> <?php if($explode[2] == "product"): ?> class="active" <?php endif; ?> <?php endif; ?>>Products</a>
                            </li>
                        </ul>
                        <!-- /.nav-second-level -->
                    </li>
                    <li>
                        <a href="<?php echo e(route('order.list')); ?>" <?php if(isset($explode[1])): ?> <?php if($explode[1] == "order"): ?> class="active" <?php endif; ?> <?php endif; ?>><i class="fa fa-table fa-fw"></i> Orders</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('contact.list')); ?>" <?php if(isset($explode[1])): ?> <?php if($explode[1] == "contact"): ?> class="active" <?php endif; ?> <?php endif; ?>><i class="fa fa-desktop fa-fw"></i> Contact</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('testimonial.list')); ?>" <?php if(isset($explode[1])): ?> <?php if($explode[1] == "testimonial"): ?> class="active" <?php endif; ?> <?php endif; ?>><i class="fa fa-reply fa-fw"></i> Testimonial</a>
                    </li>
                </ul>
            </div>
            <!-- /.sidebar-collapse -->
        </div>
        <!-- /.navbar-static-side -->
    </nav>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header"><?php echo e($title); ?></h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>

        <?php echo $__env->yieldContent("content"); ?>
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="<?php echo e(asset('assets/bower_components/jquery/dist/jquery.min.js')); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('assets/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo e(asset('assets/bower_components/metisMenu/dist/metisMenu.min.js')); ?>"></script>

<!-- Morris Charts JavaScript -->

<?php echo $__env->yieldContent("custom_js"); ?>
<!-- Custom Theme JavaScript -->
<script src="<?php echo e(asset('assets/dist/js/sb-admin-2.js')); ?>"></script>

</body>

</html>
