<?php $__env->startSection("title",$title); ?>
<?php $__env->startSection("custom_css"); ?>
    <link href="<?php echo e(asset('assets/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo e($title); ?>

                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <?php if(Session::has('success')): ?>
                        <div role="alert" class="alert alert-success alert-dismissible fade in">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="dataTable_wrapper">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>PT</th>
                                <th>Testimonial</th>
                                <th>Status</th>
                                <th>Update</th>
                                <th>Created At</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $no=0;?>
                            <?php foreach($order as $item): ?>
                                <tr class="odd gradeX">
                                    <td><?php echo e($no+=1); ?></td>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->telepon); ?></td>
                                    <td><?php echo e($item->perusahaan); ?></td>
                                    <td><?php echo e($item->isi); ?></td>
                                    <td><?php if($item->status == 0): ?> Belum Diverifikasi <?php else: ?> Sudah Diverifikasi <?php endif; ?></td>
                                    <td><?php if($item->status ==0): ?>
                                         <a href="<?php echo e(route('testimonial.update',['id'=>$item->id,'status'=>1])); ?>">Show ?</a>
                                        <?php else: ?>
                                          <a href="<?php echo e(route('testimonial.update',['id'=>$item->id,'status'=>0])); ?>">Not Show ?</a>
                                        <?php endif; ?>
                                    <td><?php echo e($item->created_at); ?></td>

                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.table-responsive -->

                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("custom_js"); ?>
    <script src="<?php echo e(asset('assets/bower_components/datatables/media/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true
            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>