<?php $__env->startSection("content"); ?>

    <div class="col-sm-9">
        <div class="blog-post-area">
            <h2 class="title text-center">Service</h2>
            <div class="single-blog-post">

                <p>
                    Express Motor menyediakan berbagai suku cadang mobil dan aksesorisnya dengan harga yang kompetitif dengan jaminan kualitas terbaik sesuai dengan visi kami yaitu pelanggan adalah nafas bisnis bagi kami, kepercayaan pelanggan adalah amanah bagi kami, serta selalu mengupayakan setiap kebutuhan pelanggan.</p>
                    Bahkan dari onderdil yang sulit anda cari ke tempat-tempat lain, kami mengupayakan availble untuk onderdil yang anda cari, demi kepuasan pelanggan.

            </div>
        </div><!--/blog-post-area-->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("frontend.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>