<?php $__env->startSection("title",$title); ?>
<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo e($title); ?>

                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <?php if(count($errors) > 0): ?>
                                <div role="alert" class="alert alert-danger alert-dismissible fade in">
                                    <?php foreach($errors->all() as $error): ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>

                            <?php echo Form::open(array('route'=>'user.store','method'=>'post')); ?>

                                <div class="form-group">
                                    <label>Name</label>
                                    <?php echo Form::text('u_name',old('name'),['class'=>'form-control','placeholder'=>'Name']); ?>


                                </div>
                                <div class="form-group">
                                    <label>Email</label>
                                    <?php echo Form::email('email',old('email'),['class'=>'form-control','placeholder'=>'Email']); ?>

                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <?php echo Form::password('password',['class'=>'form-control','placeholder'=>'Password']); ?>


                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <label class="radio-inline">
                                        <?php echo Form::radio('status', 1);; ?> Active
                                    </label>
                                    <label class="radio-inline">
                                        <?php echo Form::radio('status',2);; ?> Non active
                                    </label>

                                </div>

                                <button type="submit" class="btn btn-default">Submit Button</button>
                                <button type="reset" class="btn btn-default">Reset Button</button>
                            <?php echo Form::close(); ?>

                        </div>
                        <!-- /.col-lg-6 (nested) -->

                        <!-- /.col-lg-6 (nested) -->
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>